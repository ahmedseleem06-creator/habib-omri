import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/chat_service.dart';
import '../theme/app_theme.dart';

class ScheduledMessage {
  final String id;
  final String text;
  final String timeString; // e.g., "10:00 AM"
  final int hour;
  final int minute;
  final bool isDaily;
  bool isEnabled;

  ScheduledMessage({
    required this.id,
    required this.text,
    required this.timeString,
    required this.hour,
    required this.minute,
    this.isDaily = true,
    this.isEnabled = true,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'text': text,
    'timeString': timeString,
    'hour': hour,
    'minute': minute,
    'isDaily': isDaily,
    'isEnabled': isEnabled,
  };

  factory ScheduledMessage.fromJson(Map<String, dynamic> json) => ScheduledMessage(
    id: json['id'],
    text: json['text'],
    timeString: json['timeString'],
    hour: json['hour'],
    minute: json['minute'],
    isDaily: json['isDaily'] ?? true,
    isEnabled: json['isEnabled'] ?? true,
  );
}

class ScheduledMessagesScreen extends StatefulWidget {
  final String? initialText;
  const ScheduledMessagesScreen({super.key, this.initialText});

  @override
  State<ScheduledMessagesScreen> createState() => _ScheduledMessagesScreenState();
}

class _ScheduledMessagesScreenState extends State<ScheduledMessagesScreen> {
  final List<ScheduledMessage> _schedules = [];
  static const String _prefKey = "couples_scheduled_messages";

  final List<String> _romanticTemplates = [
    "صباح الخير يا نور عيني وأجمل رزق في حياتي ☀️❤️",
    "مساء الورد والياسمين لخطيبتي وحبيبة قلبي 🌙💍",
    "وحشتيني أوي.. ربنا يجمعنا في بيتنا وحلالنا قريب 🌹",
    "افتكرتك فجأة وابتسمت.. بحبك يا مروة 👑",
    "دعوة من قلبي ربنا يحميكي ليا ويجعل أيامك فرحة ✨",
  ];

  @override
  void initState() {
    super.initState();
    _loadSchedules();
    if (widget.initialText != null && widget.initialText!.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showAddDialog(initialText: widget.initialText);
      });
    }
  }

  Future<void> _loadSchedules() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_prefKey);
    if (data != null) {
      final List<dynamic> list = jsonDecode(data);
      setState(() {
        _schedules.clear();
        _schedules.addAll(list.map((e) => ScheduledMessage.fromJson(e)));
      });
    } else {
      // Seed default romantic schedules
      setState(() {
        _schedules.addAll([
          ScheduledMessage(
            id: "1",
            text: "صباح الخير يا حبيب عمري ونور عيني ☀️❤️",
            timeString: "10:00 ص",
            hour: 10,
            minute: 0,
            isDaily: true,
          ),
          ScheduledMessage(
            id: "2",
            text: "تصبحي على جنة يا أجمل مروة في الكون 🌙✨💍",
            timeString: "11:30 م",
            hour: 23,
            minute: 30,
            isDaily: true,
          ),
        ]);
      });
      _saveSchedules();
    }
  }

  Future<void> _saveSchedules() async {
    final prefs = await SharedPreferences.getInstance();
    final list = _schedules.map((e) => e.toJson()).toList();
    await prefs.setString(_prefKey, jsonEncode(list));
  }

  void _showAddDialog({String? initialText}) {
    final textController = TextEditingController(text: initialText ?? "");
    TimeOfDay selectedTime = const TimeOfDay(hour: 10, minute: 0);

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: AppTheme.surfaceElevated,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: const Text("⏰", style: TextStyle(fontSize: 18)),
              ),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  "رسائل مجدولة وإرسال فوري 💌",
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("نص الرسالة:", style: TextStyle(fontSize: 12, color: AppTheme.textMuted)),
                const SizedBox(height: 6),
                TextField(
                  controller: textController,
                  maxLines: 2,
                  style: const TextStyle(color: Colors.white, fontSize: 13.5),
                  decoration: InputDecoration(
                    hintText: "اكتب كلمتك لحبيبتك مروة...",
                    hintStyle: const TextStyle(color: AppTheme.textHint, fontSize: 12.5),
                    filled: true,
                    fillColor: AppTheme.surface,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                  ),
                ),

                const SizedBox(height: 10),

                // Quick Templates
                const Text("أو اختر عبارة حب سريعة:", style: TextStyle(fontSize: 11, color: AppTheme.textMuted)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: _romanticTemplates.map((t) {
                    return InkWell(
                      onTap: () {
                        setDialogState(() {
                          textController.text = t;
                        });
                      },
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppTheme.surface,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppTheme.primaryLight.withOpacity(0.2)),
                        ),
                        child: Text(
                          t,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 10.5, color: AppTheme.primaryLight),
                        ),
                      ),
                    );
                  }).toList(),
                ),

                const SizedBox(height: 14),

                const Text("وقت الجدولة (تتكرر يومياً):", style: TextStyle(fontSize: 12, color: AppTheme.textMuted)),
                const SizedBox(height: 6),
                InkWell(
                  onTap: () async {
                    final picked = await showTimePicker(
                      context: context,
                      initialTime: selectedTime,
                    );
                    if (picked != null) {
                      setDialogState(() => selectedTime = picked);
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.primary.withOpacity(0.4)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "${selectedTime.format(context)} (يومياً)",
                          style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppTheme.primaryLight),
                        ),
                        Icon(Icons.access_time_rounded, color: AppTheme.primaryLight, size: 20),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          actionsPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          actions: [
            // Row of Action Buttons: Send Now vs Schedule at Specific Time
            Row(
              children: [
                // 1. Send Now Button
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      final txt = textController.text.trim();
                      if (txt.isNotEmpty) {
                        Navigator.pop(ctx);
                        _sendNowText(txt);
                      }
                    },
                    icon: const Icon(Icons.send_rounded, size: 14, color: Colors.white),
                    label: const Text(
                      "إرسال الآن 🚀",
                      style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    style: OutlinedButton.styleFrom(
                      backgroundColor: AppTheme.accentPink.withOpacity(0.2),
                      side: const BorderSide(color: AppTheme.accentPink),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
                const SizedBox(width: 8),

                // 2. Schedule Message Button
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      final txt = textController.text.trim();
                      if (txt.isNotEmpty) {
                        setState(() {
                          _schedules.add(ScheduledMessage(
                            id: DateTime.now().millisecondsSinceEpoch.toString(),
                            text: txt,
                            timeString: selectedTime.format(context),
                            hour: selectedTime.hour,
                            minute: selectedTime.minute,
                            isDaily: true,
                          ));
                        });
                        _saveSchedules();
                        Navigator.pop(ctx);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text("تمت جدولة الرسالة لوقت ${selectedTime.format(context)} بنجاح ⏰❤️"),
                            backgroundColor: AppTheme.primary,
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.alarm_add_rounded, size: 15, color: Colors.white),
                    label: const Text(
                      "جدولة بوقت ⏰",
                      style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _deleteSchedule(int index) {
    setState(() {
      _schedules.removeAt(index);
    });
    _saveSchedules();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("تم حذف الرسالة المجدولة")),
    );
  }

  void _sendNowText(String text) {
    ChatService().sendMessage(text);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("تم إرسال الرسالة إلى الشات الآن بنجاح! 💌🚀"),
        backgroundColor: Color(0xFF10B981),
      ),
    );
  }

  void _sendNow(ScheduledMessage item) {
    _sendNowText(item.text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: AppTheme.surface,
        elevation: 1,
        title: const Text("الرسائل المجدولة والتلقائية ⏰", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddDialog(),
        backgroundColor: AppTheme.primary,
        icon: const Icon(Icons.add_alarm_rounded, color: Colors.white),
        label: const Text("رسالة جديدة", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
      ),
      body: _schedules.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.schedule_rounded, size: 60, color: AppTheme.primaryLight.withOpacity(0.4)),
                  const SizedBox(height: 12),
                  const Text("لا توجد رسائل مجدولة حالياً", style: TextStyle(color: AppTheme.textMuted)),
                  const SizedBox(height: 6),
                  const Text("اضغط على 'رسالة جديدة' لجدولة صباح الخير أو إرسالها الآن", style: TextStyle(color: AppTheme.textHint, fontSize: 12)),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _schedules.length,
              itemBuilder: (context, index) {
                final item = _schedules[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceElevated,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: item.isEnabled ? AppTheme.primary.withOpacity(0.35) : Colors.white10,
                      width: 1.2,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: AppTheme.primary.withOpacity(0.18),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.alarm_rounded, size: 14, color: AppTheme.primaryLight),
                                    const SizedBox(width: 4),
                                    Text(
                                      item.timeString,
                                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppTheme.primaryLight),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              const Text("• تتكرر يومياً", style: TextStyle(fontSize: 11, color: AppTheme.textHint)),
                            ],
                          ),
                          Switch(
                            value: item.isEnabled,
                            activeColor: AppTheme.primaryLight,
                            onChanged: (val) {
                              setState(() => item.isEnabled = val);
                              _saveSchedules();
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        item.text,
                        style: const TextStyle(fontSize: 14, color: Colors.white, height: 1.4),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Send Now Button
                          ElevatedButton.icon(
                            onPressed: () => _sendNow(item),
                            icon: const Icon(Icons.send_rounded, size: 14, color: Colors.white),
                            label: const Text(
                              "إرسال الآن 🚀",
                              style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primary,
                              elevation: 2,
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline_rounded, size: 20, color: Colors.redAccent),
                            onPressed: () => _deleteSchedule(index),
                            tooltip: "حذف الرسالة",
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
