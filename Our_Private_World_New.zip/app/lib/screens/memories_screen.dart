import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';

class MemoriesScreen extends StatefulWidget {
  const MemoriesScreen({super.key});

  @override
  State<MemoriesScreen> createState() => _MemoriesScreenState();
}

class _MemoriesScreenState extends State<MemoriesScreen> {
  String _userPhone = "";
  String _userName = "أحمد";
  String _partnerName = "مروة";
  Timer? _timer;

  // Love Dates
  final DateTime _loveStartDate = DateTime(2022, 2, 18); // 18 Feb 2022
  final DateTime _engagementDate = DateTime(2027, 7, 1);  // 1 July 2027

  @override
  void initState() {
    super.initState();
    _loadUser();
    // Update every minute for live countdown ticker
    _timer = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _loadUser() async {
    final phone = await AuthService().getUserPhone() ?? "";
    final name = await AuthService().getUserName();
    final partner = await AuthService().getPartnerName();

    if (mounted) {
      setState(() {
        _userPhone = phone;
        _userName = name;
        _partnerName = partner;
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // Calculate days together
  Duration get _togetherDuration => DateTime.now().difference(_loveStartDate);

  // Calculate next birthday countdown
  Duration _getCountdownToNext(int month, int day) {
    final now = DateTime.now();
    DateTime target = DateTime(now.year, month, day);
    if (target.isBefore(now)) {
      target = DateTime(now.year + 1, month, day);
    }
    return target.difference(now);
  }

  @override
  Widget build(BuildContext context) {
    final isAhmed = _userPhone == "01021983866" || _userName.contains("أحمد");
    final marwaCountdown = _getCountdownToNext(4, 1);  // April 1
    final ahmedCountdown = _getCountdownToNext(7, 1);  // July 1
    final engagementCountdown = _engagementDate.difference(DateTime.now());

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: AppTheme.surface,
        elevation: 1,
        title: const Text(
          "ركن الذكريات ومحطات حبنا 💍",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.textMain),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Top Romantic Banner
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF4A154B), Color(0xFF1D0E2E)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppTheme.primaryLight.withOpacity(0.3)),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.primary.withOpacity(0.25),
                    blurRadius: 18,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Text("👰🏻‍♀️ ❤️ 🤵🏻‍♂️", style: TextStyle(fontSize: 34)),
                  const SizedBox(height: 8),
                  const Text(
                    "عالم أحمد ومروة الخاص",
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text(
                      "\"بحبك يا مروة وربنا يجعلك حلالي ونور عيني\"",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 13, color: Color(0xFFF472B6), fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ).animate().fadeIn(duration: 600.ms).slideY(begin: 0.08, end: 0),

            const SizedBox(height: 18),

            // 1. LOVE DAYS COUNTER (عداد أيام حبنا)
            _buildDaysTogetherCard(),

            const SizedBox(height: 16),

            // 2. ENGAGEMENT COUNTDOWN (العد التنازلي لخطوبتنا وحلالي - النسخة الأصلية الفخمة)
            _buildGrandEngagementCountdownCard(engagementCountdown),

            const SizedBox(height: 16),

            // 3. UNFORGETTABLE MILESTONES (محطات لا تُنسى في حبنا)
            _buildMilestonesTimelineCard(),

            const SizedBox(height: 16),

            // 4. BIRTHDAY COUNTDOWNS (أعياد ميلادنا)
            Row(
              children: [
                Expanded(
                  child: _buildMiniBirthdayCard(
                    title: "عيد ميلاد مروة 🌸",
                    dateText: "1 إبريل",
                    duration: marwaCountdown,
                    accentColor: const Color(0xFFEC4899),
                    emoji: "🎂",
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildMiniBirthdayCard(
                    title: "عيد ميلاد أحمد 👑",
                    dateText: "1 يوليو",
                    duration: ahmedCountdown,
                    accentColor: const Color(0xFFA855F7),
                    emoji: "🎉",
                  ),
                ),
              ],
            ),

            const SizedBox(height: 18),

            // 5. ROMANTIC PROMISE FOOTER
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.surfaceElevated,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withOpacity(0.06)),
              ),
              child: const Row(
                children: [
                  Text("💫", style: TextStyle(fontSize: 24)),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      "\"كل يوم بيعدي وأنتي معايا، بتأكد إنك أجمل اختيار ورزق من ربنا، وخطوبتنا هتكون أجمل فرحة في حياتنا\"",
                      style: TextStyle(fontSize: 11.5, color: AppTheme.textMuted, height: 1.5, fontStyle: FontStyle.italic),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // 1. Days Together Card
  Widget _buildDaysTogetherCard() {
    final days = _togetherDuration.inDays;
    final years = (days / 365).floor();
    final remainingDays = days % 365;
    final months = (remainingDays / 30).floor();
    final finalDays = remainingDays % 30;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.surfaceElevated,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.accentPink.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.favorite_rounded, color: AppTheme.accentPink, size: 20),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "عداد أيام حبنا (معاً منذ 18/2/2022) ❤️",
                      style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.bold, color: AppTheme.textMain),
                    ),
                    Text(
                      "كل ثانية حب وسعادة مع حبيب عمري",
                      style: TextStyle(fontSize: 11, color: AppTheme.textMuted),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Center(
            child: Column(
              children: [
                Text(
                  "$days",
                  style: const TextStyle(
                    fontSize: 46,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                    color: Color(0xFFC084FC),
                  ),
                ),
                const Text(
                  "يوماً من الحب والوفاء والقادم أجمل بإذن الله",
                  style: TextStyle(fontSize: 12.5, color: AppTheme.textMuted),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildMiniMetric("$years", "سنوات حب"),
              Container(width: 1, height: 28, color: Colors.white12),
              _buildMiniMetric("$months", "أشهر"),
              Container(width: 1, height: 28, color: Colors.white12),
              _buildMiniMetric("$finalDays", "أيام"),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMiniMetric(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        Text(label, style: const TextStyle(fontSize: 11, color: AppTheme.textMuted)),
      ],
    );
  }

  // 2. Grand Engagement Countdown Card (Original Rich Design)
  Widget _buildGrandEngagementCountdownCard(Duration duration) {
    final days = duration.inDays;
    final hours = duration.inHours % 24;
    final minutes = duration.inMinutes % 60;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF26153B), Color(0xFF38153C)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.5), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFF59E0B).withOpacity(0.15),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFF59E0B).withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: const Text("💍", style: TextStyle(fontSize: 22)),
              ),
              const SizedBox(width: 10),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "العد التنازلي ليوم خطوبتنا وحلالي 💍",
                    style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  Text(
                    "1 يوليو 2027 • اليوم الموعود وعالمنا الدائم",
                    style: TextStyle(fontSize: 11, color: Color(0xFFFBBF24)),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          // 3 Countdown Blocks
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildCountdownBox("$days", "يوم متبقي", const Color(0xFFFBBF24)),
              const SizedBox(width: 8),
              _buildCountdownBox("$hours", "ساعة", Colors.white70),
              const SizedBox(width: 8),
              _buildCountdownBox("$minutes", "دقيقة", Colors.white70),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Text(
              "\"ربنا يجمعنا على خير وسنة رسوله يا قرة عيني ونور حياتي\" ❤️",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: Color(0xFFFDE68A), fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCountdownBox(String val, String unit, Color color) {
    return Container(
      width: 80,
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.surface.withOpacity(0.8),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text(val, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
          Text(unit, style: const TextStyle(fontSize: 9.5, color: AppTheme.textMuted)),
        ],
      ),
    );
  }

  // 3. Milestones Timeline (محطات لا تُنسى في حبنا)
  Widget _buildMilestonesTimelineCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.surfaceElevated,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.timeline_rounded, color: Color(0xFFC084FC), size: 20),
              ),
              const SizedBox(width: 10),
              const Text(
                "محطات لا تُنسى في حبنا ✨",
                style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ],
          ),
          const SizedBox(height: 16),

          _buildMilestoneItem(
            date: "18 فبراير 2022",
            title: "بداية حكايتنا وأجمل يوم في العمر ❤️",
            desc: "أول نبضة حب جمعت بين قلب أحمد وقلب مروة وبداية الوعد الصادق",
            icon: "💘",
            isFirst: true,
          ),
          _buildMilestoneItem(
            date: "1 إبريل 1997",
            title: "ميلاد أميرتي مروة 🌸",
            desc: "اليوم اللي اتولدت فيه أجمل هدية رزقني بيها ربنا ونور عيني",
            icon: "🎂",
          ),
          _buildMilestoneItem(
            date: "1 يوليو 1995",
            title: "ميلاد حبيب عمري وسندي أحمد 👑",
            desc: "اليوم اللي اتولد فيه بطلي ورجلي وأمان حياتي كلها",
            icon: "👑",
          ),
          _buildMilestoneItem(
            date: "1 يوليو 2027",
            title: "اليوم الموعود • خطوبتنا وحلالنا 💍",
            desc: "اليوم اللي هنلبس فيه الدبل ونعلن عالمنا الخاص أمام الدنيا كلها على سنة الله",
            icon: "👰🏻‍♀️",
            isLast: true,
          ),
        ],
      ),
    );
  }

  Widget _buildMilestoneItem({
    required String date,
    required String title,
    required String desc,
    required String icon,
    bool isFirst = false,
    bool isLast = false,
  }) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Icon and connecting vertical line
          Column(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppTheme.primaryLight.withOpacity(0.4)),
                ),
                child: Center(child: Text(icon, style: const TextStyle(fontSize: 15))),
              ),
              if (!isLast)
                Expanded(
                  child: Container(
                    width: 2,
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    color: AppTheme.primaryLight.withOpacity(0.25),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      date,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.primaryLight,
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    title,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    desc,
                    style: const TextStyle(fontSize: 11, color: AppTheme.textMuted, height: 1.4),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 4. Mini Birthday Card
  Widget _buildMiniBirthdayCard({
    required String title,
    required String dateText,
    required Duration duration,
    required Color accentColor,
    required String emoji,
  }) {
    final days = duration.inDays;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surfaceElevated,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: accentColor.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 16)),
              const SizedBox(width: 6),
              Text(
                title,
                style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            dateText,
            style: TextStyle(fontSize: 10.5, color: accentColor, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: AppTheme.surface,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              "فاضل $days يوم",
              style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: accentColor),
            ),
          ),
        ],
      ),
    );
  }
}
