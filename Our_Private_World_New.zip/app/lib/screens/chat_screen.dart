import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart' as intl;
import 'package:shared_preferences/shared_preferences.dart';
import '../services/auth_service.dart';
import '../services/chat_service.dart';
import '../theme/app_theme.dart';
import 'lock_screen.dart';
import 'login_screen.dart';
import 'memories_screen.dart';
import 'scheduled_messages_screen.dart';
import 'settings_screen.dart';
import 'stories_screen.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'love_hub_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _textController = TextEditingController();
  bool _hasText = false;
  final ScrollController _scrollController = ScrollController();
  final List<Map<String, dynamic>> _messages = [];
  final ImagePicker _picker = ImagePicker();

  String _myPhone = "";
  String _partnerName = "مروة عمري";
  bool _isPartnerOnline = false;
  bool _isPartnerTyping = false;
  bool _isUploading = false;
  bool _showEmojiPicker = false;
  String? _wallpaperPath;
  String? _myAvatarPath;
  String? _partnerAvatarPath;
  List<String> _recentEmojis = [
    '❤️', '💍', '🥰', '🥺', '🌸', '👰🏻‍♀️', '🤵🏻‍♂️', '✨', '💋', '🔥'
  ];
  double _wallpaperOpacity = 0.35;
  String _myMood = "مشتاق لك وبفكر فيك 🥺❤️";
  String _partnerMood = "طايرة من الفرحة ومبسوطة 🥰✨";
  Timer? _typingTimer;
  StreamSubscription? _chatSubscription;

  // =========================================================
  // Comprehensive WhatsApp & Telegram Full Categorized Emojis (8 Categories)
  // =========================================================
  final List<String> _loveEmojis = [
    '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔',
    '❤️‍🔥', '❤️‍🩹', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝',
    '💟', '💌', '🫶', '🫰', '💍', '💎', '💐', '🌹', '🥀', '🌺',
    '🌸', '🌼', '🌻', '🌷', '👰🏻‍♀️', '🤵🏻‍♂️', '👩‍❤️‍👨', '👩‍❤️‍💋‍👨', '💏', '💑',
    '🫂', '💋', '👑', '🕊️', '🥂', '🧸', '💒', '🎂', '🕯️', '🪄',
    '🫀', '🥰', '😍', '😘', '🥺', '😻', '😚', '😙', '✨', '⭐',
    '🌟', '💫', '🌙', '☀️', '🎀', '🎁', '💐', '🌷', '💌', '💍'
  ];

  final List<String> _smileysEmojis = [
    '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '🥲', '🥹',
    '☺️', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘',
    '😗', '😙', '😚', '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐',
    '🤓', '😎', '🥸', '🤩', '🥳', '😏', '😒', '😞', '😔', '😟',
    '😕', '🙁', '☹️', '😣', '😖', '😫', '😩', '🥺', '😢', '😭',
    '😮‍💨', '😤', '😠', '😡', '🤬', '🤯', '😳', '🥵', '🥶', '😱',
    '😨', '😰', '😥', '😓', '🫣', '🤗', '🫡', '🤔', '🫢', '🤫',
    '🤥', '😶', '😶‍🌫️', '😐', '😑', '😬', '🫨', '🫠', '🙄', '😯',
    '😦', '😧', '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '😵‍💫',
    '🤐', '🥴', '🤢', '🤮', '🤧', '😷', '🤒', '🤕', '🤑', '🤠',
    '😈', '👿', '👹', '👺', '🤡', '💩', '👻', '💀', '☠️', '👽'
  ];

  final List<String> _gesturesEmojis = [
    '👍', '👎', '👌', '🤌', '🤏', '✌️', '🤞', '🫰', '🤟', '🤘',
    '🤙', '👈', '👉', '👆', '👇', '☝️', '✋', '🤚', '🖐️', '🖖',
    '👋', '🤝', '👏', '🙌', '👐', '🤲', '🙏', '✍️', '💅', '🤳',
    '💪', '🦾', '🦿', '🦵', '🦶', '👂', '👃', '🧠', '👀', '👁️',
    '👅', '👄', '🫦', '🫂', '🧑‍🤝‍🧑', '👭', '👬', '👫', '💃', '🕺',
    '🏃‍♂️', '🏃‍♀️', '🚶‍♂️', '🚶‍♀️', '🧍‍♂️', '🧍‍♀️', '🧎‍♂️', '🧎‍♀️', '🙋‍♂️', '🙋‍♀️',
    '🤷‍♂️', '🤷‍♀️', '🤦‍♂️', '🤦‍♀️', '🙇‍♂️', '🙇‍♀️', '💁‍♂️', '💁‍♀️', '🙅‍♂️', '🙅‍♀️'
  ];

  final List<String> _natureEmojis = [
    '🌹', '💐', '🌷', '🌺', '🌸', '🌼', '🌻', '🥀', '🍀', '☘️',
    '🌿', '🌱', '🌾', '🪴', '🌴', '🌳', '🌲', '🍂', '🍁', '🍄',
    '🐱', '🐶', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮',
    '🐷', '🐸', '🐵', '🐔', '🐧', '🐦', '🐤', '🦆', '🦅', '🦉',
    '🦇', '🐺', '🐴', '🦄', '🐝', '🦋', '🐌', '🐞', '🐢', '🐍',
    '🐙', '🐬', '🐳', '🐟', '🐡', '🐠', '🦭', '🐆', '🦓', '🦒',
    '🐘', '🦔', '🕊️', '🐾', '🪴', '🍃', '☀️', '🌤️', '⛅', '🌈'
  ];

  final List<String> _foodEmojis = [
    '☕', '🫖', '🧃', '🥤', '🧋', '🥛', '🍼', '🍫', '🍬', '🍭',
    '🎂', '🍰', '🧁', '🍩', '🍪', '🍨', '🍧', '🍦', '🥧', '🍓',
    '🍒', '🍎', '🍏', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🫐',
    '🍈', '🍑', '🥭', '🍍', '🥥', '🥝', '🥞', '🧇', '🍕', '🍔',
    '🍟', '🌭', '🥪', '🌮', '🌯', '🥗', '🍝', '🍜', '🍲', '🍛',
    '🍣', '🍱', '🥟', '🍤', '🍿', '🧈', '🧀', '🍳', '🥐', '🥖'
  ];

  final List<String> _activitiesEmojis = [
    '🎉', '🎊', '🎈', '🎁', '🎀', '🪄', '🪅', '✨', '⭐', '🌟',
    '💫', '🔥', '💥', '🏆', '🥇', '🥈', '🥉', '🏅', '🎖️', '🎫',
    '🎟️', '🎪', '🎭', '🎨', '🎬', '🎤', '🎧', '🎼', '🎹', '🥁',
    '🎷', '🎺', '🎸', '🎻', '🎲', '🎯', '🎳', '🎮', '🕹️', '🎰',
    '🧩', '⚽', '🏀', '🏈', '⚾', '🎾', '🏐', '🏓', '🏸', '🥊',
    '🥋', '🛹', '🛼', '🚴‍♂️', '🚴‍♀️', '🏊‍♂️', '🏊‍♀️', '🏄‍♂️', '🏄‍♀️', '🧗‍♂️'
  ];

  final List<String> _travelEmojis = [
    '✈️', '🛫', '🛬', '🚀', '🛸', '🚁', '🚗', '🚕', '🚙', '🚌',
    '🏎️', '🚓', '🚑', '🚒', '🛵', '🏍️', '🚲', '🛴', '🚂', '🚆',
    '🚇', '🚊', '⛵', '🚤', '🛳️', '🚢', '🏖️', '🏝️', '🏜️', '🌋',
    '⛰️', '🏔️', '🏕️', '⛺', '🏠', '🏡', '🏘️', '🏰', '🗼', '🗽',
    '🏟️', '🎡', '🎢', '🎠', '⛲', '🕋', '🕌', '🌅', '🌄', '🌇',
    '🌆', '🌃', '🌌', '🌙', '🪐', '⛺', '🏖️', '🏨', '💒', '🏛️'
  ];

  final List<String> _symbolsEmojis = [
    '💌', '💎', '💍', '👑', '💡', '🕯️', '📱', '📲', '💻', '⌚',
    '⏰', '⏱️', '⏳', '⌛', '🔑', '🗝️', '🔒', '🔓', '🔏', '🔐',
    '❤️', '💖', '⚡', '☀️', '🌤️', '⛅', '🌧️', '⛈️', '❄️', '☃️',
    '🌈', '☂️', '☔', '🧿', '🪬', '🔮', '📿', '🔔', '🔕', '📢',
    '📣', '💬', '💭', '🗯️', '💯', '✅', '✔️', '☑️', '❌', '❎',
    '❓', '❗', '‼️', '⁉️', '➕', '➖', '✖️', '➗', '💲', '💱'
  ];
  int _selectedEmojiCategory = 0;

  @override
  void initState() {
    super.initState();
    _initChat();
    _loadSettings();
    _textController.addListener(() {
      final has = _textController.text.trim().isNotEmpty;
      if (has != _hasText && mounted) {
        setState(() {
          _hasText = has;
        });
      }
    });
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final path = await AuthService().getChatWallpaper();
    final op = await AuthService().getWallpaperOpacity();
    final themeId = prefs.getString("selected_app_theme") ?? "violet";
    final avatar = prefs.getString("user_custom_avatar");
    final partnerAvatar = prefs.getString("partner_custom_avatar");
    final recents = prefs.getStringList("recent_emojis");
    AppTheme.setTheme(themeId);

    if (mounted) {
      setState(() {
        _wallpaperPath = path;
        _wallpaperOpacity = op;
        _myAvatarPath = avatar;
        _partnerAvatarPath = partnerAvatar;
        if (recents != null && recents.isNotEmpty) {
          _recentEmojis = recents;
        }
      });
    }
  }

  Future<void> _initChat() async {
    final phone = await AuthService().getUserPhone();
    if (phone == null) {
      _logout();
      return;
    }

    final isAhmed = phone == "01021983866";

    setState(() {
      _myPhone = phone;
      _partnerName = isAhmed ? "مروة عمري 💍" : "أحمد حبيب قلبي 👑";
    });

    // 1. Fetch historical messages
    final history = await ChatService().fetchHistory(phone);
    if (mounted) {
      setState(() {
        _messages.addAll(history);
        if (_messages.isEmpty) {
          _messages.addAll([
            {
              "id": 1,
              "sender_phone": isAhmed ? "01156165169" : "01021983866",
              "receiver_phone": phone,
              "content": "صباح الخير يا نور عيني وأجمل رزق في حياتي.. وحشتني أوي، كل يوم بيعدي بيقربنا ليوم خطوبتنا وحلالنا 💍💜",
              "msg_type": "text",
              "media_url": "",
              "status": "read",
              "timestamp": DateTime.now().subtract(const Duration(minutes: 30)).millisecondsSinceEpoch / 1000,
              "is_liked": 1,
              "reaction_emoji": "❤️",
            },
            {
              "id": 2,
              "sender_phone": phone,
              "receiver_phone": isAhmed ? "01156165169" : "01021983866",
              "content": "يا روحي وقلبي أنتي.. بحبك وربنا يجعلك حلالي دايماً وسندي ونور أيامي، ومستني اليوم الموعود على نار ❤️✨",
              "msg_type": "text",
              "media_url": "",
              "status": "read",
              "timestamp": DateTime.now().subtract(const Duration(minutes: 25)).millisecondsSinceEpoch / 1000,
              "is_liked": 1,
              "reaction_emoji": "💍",
            },
          ]);
        }
      });
      _scrollToBottom();
    }

    // 2. Connect WebSocket
    ChatService().connect(phone);

    // 3. Listen to incoming real-time events
    _chatSubscription = ChatService().messageStream.listen((event) {
      if (!mounted) return;

      final type = event["event"];

      if (type == "new_message") {
        setState(() {
          _messages.add(event);
        });
        _scrollToBottom();

        if (event["receiver_phone"] == _myPhone && event["id"] != null) {
          ChatService().sendReadReceipt([event["id"]]);
        }
      } else if (type == "heartbeat" || type == "heartbeat_received") {
        _onReceiveHeartbeat(event["sender_name"] ?? "حبيبك");
      } else if (type == "partner_mood_updated" || type == "mood_update") {
        if (mounted) {
          setState(() {
            _partnerMood = event["mood"] ?? "";
          });
        }
      } else if (type == "typing") {
        setState(() {
          _isPartnerTyping = event["is_typing"] ?? false;
        });
      } else if (type == "presence") {
        setState(() {
          _isPartnerOnline = event["is_online"] ?? false;
        });
      } else if (type == "messages_read") {
        final List<dynamic> ids = event["message_ids"] ?? [];
        setState(() {
          for (var msg in _messages) {
            if (ids.contains(msg["id"])) {
              msg["status"] = "read";
            }
          }
        });
      } else if (type == "message_liked") {
        final msgId = event["message_id"];
        final isLiked = event["is_liked"] ?? 0;
        setState(() {
          for (var msg in _messages) {
            if (msg["id"] == msgId) {
              msg["is_liked"] = isLiked;
            }
          }
        });
      }
    });
  }

  void _sendMessage({String msgType = "text", String mediaUrl = "", String textOverride = ""}) {
    final text = textOverride.isNotEmpty ? textOverride : _textController.text.trim();
    if (text.isEmpty && mediaUrl.isEmpty) return;

    final localMsg = {
      "id": DateTime.now().millisecondsSinceEpoch,
      "sender_phone": _myPhone,
      "receiver_phone": _myPhone == "01021983866" ? "01156165169" : "01021983866",
      "content": text,
      "msg_type": msgType,
      "media_url": mediaUrl,
      "status": "delivered",
      "timestamp": DateTime.now().millisecondsSinceEpoch / 1000,
      "is_liked": 0,
    };
    if (!ChatService().isConnected) {
      setState(() {
        _messages.add(localMsg);
      });
    }

    ChatService().sendMessage(text, msgType: msgType, mediaUrl: mediaUrl);
    if (textOverride.isEmpty) {
      _textController.clear();
      setState(() => _hasText = false);
      _onTextChanged("");
    }
    _scrollToBottom();
  }

  // Multi-Image Picker
  Future<void> _pickAndSendMultipleImages() async {
    try {
      final List<XFile> files = await _picker.pickMultiImage(imageQuality: 90);
      if (files.isEmpty) return;

      setState(() => _isUploading = true);

      for (var file in files) {
        final request = http.MultipartRequest(
          'POST',
          Uri.parse("${AuthService().serverUrl}/api/upload"),
        );
        request.files.add(await http.MultipartFile.fromPath('file', file.path));
        final streamedResponse = await request.send();
        final response = await http.Response.fromStream(streamedResponse);

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          _sendMessage(msgType: "image", mediaUrl: data["url"]);
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("تعذر رفع الصور: $e")),
      );
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  Future<void> _pickAndSendVideo() async {
    try {
      final XFile? file = await _picker.pickVideo(source: ImageSource.gallery);
      if (file == null) return;

      setState(() => _isUploading = true);

      final request = http.MultipartRequest(
        'POST',
        Uri.parse("${AuthService().serverUrl}/api/upload"),
      );
      request.files.add(await http.MultipartFile.fromPath('file', file.path));
      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _sendMessage(msgType: "video", mediaUrl: data["url"], textOverride: "🎥 مقطع فيديو");
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("تعذر رفع الفيديو: $e")),
      );
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  void _showVoiceRecorderModal() {
    int recordingSeconds = 0;
    Timer? recordTimer;
    bool isRecording = true;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: true,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          recordTimer ??= Timer.periodic(const Duration(seconds: 1), (t) {
            if (isRecording) {
              setModalState(() {
                recordingSeconds++;
              });
            }
          });

          final mins = (recordingSeconds ~/ 60).toString().padLeft(2, '0');
          final secs = (recordingSeconds % 60).toString().padLeft(2, '0');

          return Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppTheme.surfaceElevated,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              border: Border.all(color: AppTheme.primaryLight.withOpacity(0.3)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 68,
                  height: 68,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [Color(0xFFE11D48), Color(0xFFF43F5E)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.redAccent.withOpacity(0.4),
                        blurRadius: 18,
                        spreadRadius: 3,
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Icon(Icons.mic_rounded, color: Colors.white, size: 34),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: const BoxDecoration(
                        color: Colors.redAccent,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "جاري التسجيل: $mins:$secs",
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  "تحدث الآن، رسالتك الصوتية الدافئة ستصل إلى $_partnerName ❤️",
                  style: const TextStyle(fontSize: 12, color: AppTheme.textMuted),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          recordTimer?.cancel();
                          Navigator.pop(ctx);
                        },
                        icon: const Icon(Icons.close_rounded, color: Colors.white70, size: 18),
                        label: const Text("إلغاء", style: TextStyle(color: Colors.white70)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Colors.white24),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          recordTimer?.cancel();
                          Navigator.pop(ctx);
                          final dur = "$mins:$secs";
                          _sendMessage(
                            msgType: "voice",
                            textOverride: "🎙️ رسالة صوتية دافئة ($dur)",
                          );
                        },
                        icon: const Icon(Icons.send_rounded, color: Colors.white, size: 16),
                        label: const Text("إرسال التسجيل 🚀", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primary,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _sendVoiceNote() {
    _showVoiceRecorderModal();
  }

  void _onTextChanged(String text) {
    final has = text.trim().isNotEmpty;
    if (has != _hasText) {
      setState(() {
        _hasText = has;
      });
    }
    if (text.isNotEmpty) {
      ChatService().sendTyping(true);
      _typingTimer?.cancel();
      _typingTimer = Timer(const Duration(seconds: 2), () {
        ChatService().sendTyping(false);
      });
    } else {
      ChatService().sendTyping(false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent + 120,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _toggleLike(Map<String, dynamic> msg, [String emoji = "❤️"]) {
    final msgId = msg["id"];
    if (msgId == null) return;
    final current = msg["is_liked"] ?? 0;
    final isSameEmoji = msg["reaction_emoji"] == emoji;
    final next = (current == 1 && isSameEmoji) ? 0 : 1;
    setState(() {
      msg["is_liked"] = next;
      msg["reaction_emoji"] = next == 1 ? emoji : null;
    });
    ChatService().toggleLike(msgId, next);
  }

  void _showMessageReactionPicker(Map<String, dynamic> msg) {
    final reactions = ["❤️", "🥰", "💍", "😂", "😮", "🥺", "🔥", "🌸"];
    showDialog(
      context: context,
      barrierColor: Colors.black26,
      builder: (ctx) => Center(
        child: Material(
          color: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: AppTheme.surfaceElevated,
              borderRadius: BorderRadius.circular(30),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 16, offset: const Offset(0, 4)),
              ],
              border: Border.all(color: AppTheme.primaryLight.withOpacity(0.3)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: reactions.map((emoji) {
                return InkWell(
                  onTap: () {
                    Navigator.pop(ctx);
                    _toggleLike(msg, emoji);
                  },
                  borderRadius: BorderRadius.circular(20),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    child: Text(emoji, style: const TextStyle(fontSize: 26)),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
    );
  }

  void _lockApp() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LockScreen()),
    );
  }

  void _logout() async {
    await AuthService().logout();
    ChatService().disconnect();
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  // Full-Screen Image Viewer with Pinch-to-Zoom
  void _openFullScreenImage(String imageUrl) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black45,
            iconTheme: const IconThemeData(color: Colors.white),
            title: const Text("عالمنا الخاص ❤️", style: TextStyle(color: Colors.white, fontSize: 16)),
          ),
          body: Center(
            child: InteractiveViewer(
              panEnabled: true,
              boundaryMargin: const EdgeInsets.all(20),
              minScale: 0.8,
              maxScale: 4.0,
              child: Image.network(
                imageUrl,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const Center(
                  child: Icon(Icons.broken_image, size: 60, color: Colors.white54),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }


  // -----------------------------------------------------------
  // Heartbeat Sync & Mood Tracker
  // -----------------------------------------------------------
  void _sendHeartbeatPulse() {
    HapticFeedback.heavyImpact();
    Future.delayed(const Duration(milliseconds: 160), () => HapticFeedback.heavyImpact());
    Future.delayed(const Duration(milliseconds: 320), () => HapticFeedback.heavyImpact());

    ChatService().sendMessage("💓 نبضة حب: أنا بفكر فيكي دلوقتي ونبضات قلبي بتناديكي ❤️", type: "heartbeat");

    _showHeartbeatOverlay(isSender: true, name: _partnerName);
  }

  void _onReceiveHeartbeat(String senderName) {
    HapticFeedback.heavyImpact();
    Future.delayed(const Duration(milliseconds: 160), () => HapticFeedback.heavyImpact());
    Future.delayed(const Duration(milliseconds: 320), () => HapticFeedback.heavyImpact());

    _showHeartbeatOverlay(isSender: false, name: senderName);
  }

  void _showHeartbeatOverlay({required bool isSender, required String name}) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const RadialGradient(
                  colors: [AppTheme.accentPink, Colors.transparent],
                  stops: [0.4, 1.0],
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.accentPink.withOpacity(0.6),
                    blurRadius: 40,
                    spreadRadius: 10,
                  ),
                ],
              ),
              child: const Center(
                child: Icon(Icons.favorite_rounded, size: 75, color: Colors.white),
              ),
            )
            .animate(onPlay: (c) => c.repeat(reverse: true))
            .scale(begin: const Offset(0.85, 0.85), end: const Offset(1.2, 1.2), duration: 600.ms),
            const SizedBox(height: 24),
            Text(
              isSender ? "تم إرسال نبضات قلبك لحبيبتك ❤️" : "$name بيبعتلك نبضات قلبه دلوقتي! 💓",
              style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, decoration: TextDecoration.none),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              isSender ? "موبايلها بيهتز بنبضات قلبك في نفس اللحظة ✨" : "بحبك يا مروة وربنا يجعلك حلالي ونور حياتي 💍",
              style: TextStyle(color: AppTheme.primaryLight, fontSize: 12, decoration: TextDecoration.none),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(ctx);
                if (!isSender) {
                  _sendHeartbeatPulse();
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accentPink),
              child: Text(isSender ? "حبيبي دايماً في بالي ❤️" : "رد بنبضة حب فورية 💓"),
            ),
          ],
        ),
      ),
    );
  }

  void _showMoodPicker() {
    final moods = [
      "مشتاق لك وبفكر فيك 🥺❤️",
      "طاير من الفرحة ومبسوط 🥰✨",
      "تعبان ومحتاج حنية ودعوة 🤒🫂",
      "مضغوط في الشغل ومحتاجك جنبي 💼🤍",
      "روقان ومستني أسمع صوتك ☕🌸",
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surfaceElevated,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("كيف تشعر الآن؟ (مؤشر المزاج العاطفي) 🥰", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.white)),
              const SizedBox(height: 6),
              const Text("سيظهر مزاجك لحبيبك في أعلى الشات فوراً ليشاركك مشاعرك:", style: TextStyle(fontSize: 11, color: AppTheme.textMuted)),
              const SizedBox(height: 14),
              ...moods.map((m) => ListTile(
                title: Text(m, style: const TextStyle(fontSize: 13, color: Colors.white)),
                trailing: _myMood == m ? const Icon(Icons.check_circle_rounded, color: AppTheme.accentPink) : null,
                onTap: () async {
                  setState(() => _myMood = m);
                  Navigator.pop(ctx);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setString("user_current_mood", m);
                  ChatService().sendMessage(m, type: "mood_update");
                },
              )),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _chatSubscription?.cancel();
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _recordRecentEmoji(String em) async {
    setState(() {
      _recentEmojis.remove(em);
      _recentEmojis.insert(0, em);
      if (_recentEmojis.length > 14) {
        _recentEmojis = _recentEmojis.sublist(0, 14);
      }
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList("recent_emojis", _recentEmojis);
  }

  void _showAvatarActionSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surfaceElevated,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Avatar with glowing story ring
              Container(
                width: 78,
                height: 78,
                padding: const EdgeInsets.all(3),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFFCB045)],
                  ),
                ),
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    color: AppTheme.surface,
                    shape: BoxShape.circle,
                  ),
                  child: CircleAvatar(
                    radius: 34,
                    backgroundColor: AppTheme.surfaceElevated,
                    backgroundImage: _partnerAvatarPath != null ? FileImage(File(_partnerAvatarPath!)) : null,
                    child: _partnerAvatarPath == null
                        ? Text(_myPhone == "01021983866" ? "👰🏻‍♀️" : "🤵🏻‍♂️", style: const TextStyle(fontSize: 34))
                        : null,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "$_partnerName 💍",
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              Text(
                _isPartnerOnline ? "متصلة الآن • نبض قلبي 🟢" : "غير متصل",
                style: TextStyle(
                  fontSize: 12,
                  color: _isPartnerOnline ? const Color(0xFF10B981) : AppTheme.textMuted,
                ),
              ),
              const SizedBox(height: 16),
              // Option 1: View Story
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(colors: [Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFFCB045)]),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.auto_stories_rounded, color: Colors.white, size: 20),
                ),
                title: const Text("عرض الحالة 🌟", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                subtitle: const Text("مشاهدة كلام وصور الحالات اليومية", style: TextStyle(color: AppTheme.textMuted, fontSize: 11.5)),
                trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.white54),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const StoriesScreen()));
                },
              ),
              // Option 2: View Profile Photo
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withOpacity(0.18),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.fullscreen_rounded, color: AppTheme.primaryLight, size: 20),
                ),
                title: const Text("عرض الصورة الشخصية 🖼️", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                subtitle: const Text("فتح الصورة بحجم الشاشة الكامل والتقريب", style: TextStyle(color: AppTheme.textMuted, fontSize: 11.5)),
                trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.white54),
                onTap: () {
                  Navigator.pop(ctx);
                  _openProfilePhotoViewer();
                },
              ),
              // Option 3: Change Profile Photo
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppTheme.accentPink.withOpacity(0.18),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.add_a_photo_rounded, color: AppTheme.accentPink, size: 20),
                ),
                title: const Text("تغيير الصورة الشخصية 📸", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                subtitle: const Text("اختيار صورة جديدة لحبيبتك من المعرض", style: TextStyle(color: AppTheme.textMuted, fontSize: 11.5)),
                trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.white54),
                onTap: () {
                  Navigator.pop(ctx);
                  _pickAndChangeProfileAvatar();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openProfilePhotoViewer() {
    showDialog(
      context: context,
      barrierColor: Colors.black87,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Align(
              alignment: Alignment.topLeft,
              child: IconButton(
                icon: const Icon(Icons.close, color: Colors.white, size: 26),
                onPressed: () => Navigator.pop(ctx),
              ),
            ),
            Container(
              constraints: const BoxConstraints(maxHeight: 380, maxWidth: 380),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppTheme.accentPink.withOpacity(0.5), width: 2),
                boxShadow: [
                  BoxShadow(color: AppTheme.accentPink.withOpacity(0.25), blurRadius: 20),
                ],
              ),
              clipBehavior: Clip.antiAlias,
              child: _partnerAvatarPath != null
                  ? Image.file(
                      File(_partnerAvatarPath!),
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _buildAvatarPlaceholder(),
                    )
                  : _buildAvatarPlaceholder(),
            ),
            const SizedBox(height: 14),
            Text(
              "الصورة الشخصية لـ $_partnerName ❤️",
              style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              _myPhone == "01021983866" ? "حبيبة قلبي ونور عيني مروة 💍" : "حبيبي وسندي أحمد 🤵🏻‍♂️",
              style: const TextStyle(color: AppTheme.accentPink, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAvatarPlaceholder() {
    return Container(
      width: 280,
      height: 280,
      color: AppTheme.surfaceElevated,
      child: Center(
        child: Text(
          _myPhone == "01021983866" ? "👰🏻‍♀️" : "🤵🏻‍♂️",
          style: const TextStyle(fontSize: 100),
        ),
      ),
    );
  }

  Future<void> _pickAndChangeProfileAvatar() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (file != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString("partner_custom_avatar", file.path);
      setState(() {
        _partnerAvatarPath = file.path;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("تم تحديث الصورة الشخصية بنجاح 📷✨"),
            backgroundColor: Color(0xFF10B981),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: AppTheme.surface,
        elevation: 1,
        titleSpacing: 0,
        title: Row(
          children: [
            // Avatar with Instagram/WhatsApp Story Glowing Ring
            GestureDetector(
              onTap: _showAvatarActionSheet,
              child: Stack(
                children: [
                  Container(
                    width: 45,
                    height: 45,
                    padding: const EdgeInsets.all(2.2),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFFCB045)],
                      ),
                    ),
                    child: Container(
                      padding: const EdgeInsets.all(1.5),
                      decoration: BoxDecoration(
                        color: AppTheme.surface,
                        shape: BoxShape.circle,
                      ),
                      child: CircleAvatar(
                        radius: 19,
                        backgroundColor: AppTheme.surfaceElevated,
                        backgroundImage: _partnerAvatarPath != null ? FileImage(File(_partnerAvatarPath!)) : null,
                        child: _partnerAvatarPath == null
                            ? Text(_myPhone == "01021983866" ? "👰🏻‍♀️" : "🤵🏻‍♂️", style: const TextStyle(fontSize: 19))
                            : null,
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: _isPartnerOnline ? const Color(0xFF10B981) : Colors.grey,
                        shape: BoxShape.circle,
                        border: Border.all(color: AppTheme.surface, width: 2),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            // Partner Name & Status
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _partnerName,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.textMain,
                    ),
                  ),
                  Text(
                    _isPartnerTyping
                        ? "يكتب الآن... ✍️"
                        : (_isPartnerOnline ? "متصلة الآن 🟢" : "غير متصل"),
                    style: TextStyle(
                      fontSize: 11,
                      color: _isPartnerTyping
                          ? AppTheme.primaryLight
                          : (_isPartnerOnline ? const Color(0xFF10B981) : AppTheme.textMuted),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          // Prominent Live Heartbeat button right in the AppBar
          InkWell(
            onTap: _sendHeartbeatPulse,
            borderRadius: BorderRadius.circular(20),
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.accentPink.withOpacity(0.18),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppTheme.accentPink.withOpacity(0.4)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Text("💓", style: TextStyle(fontSize: 16)),
                  SizedBox(width: 4),
                  Text("نبضة", style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppTheme.accentPink)),
                ],
              ),
            ),
          ),
          // Clean 3-dots menu for secondary options
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded, color: AppTheme.textMuted),
            color: AppTheme.surfaceElevated,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            onSelected: (val) {
              if (val == "stories") {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const StoriesScreen()));
              } else if (val == "scheduled") {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ScheduledMessagesScreen()));
              } else if (val == "lock") {
                _lockApp();
              }
            },
            itemBuilder: (ctx) => [
              const PopupMenuItem(
                value: "stories",
                child: Text("حالات عالمنا الخاص 🌟", style: TextStyle(color: Colors.white, fontSize: 13)),
              ),
              const PopupMenuItem(
                value: "scheduled",
                child: Text("الرسائل اليومية المجدولة ⏰", style: TextStyle(color: Colors.white, fontSize: 13)),
              ),
              const PopupMenuItem(
                value: "lock",
                child: Text("قفل التطبيق 🔒", style: TextStyle(color: Colors.white, fontSize: 13)),
              ),
            ],
          ),
        ],
      ),
      body: Stack(
        children: [
          // Custom Wallpaper Background if selected
          if (_wallpaperPath != null)
            Positioned.fill(
              child: Opacity(
                opacity: _wallpaperOpacity,
                child: Image.file(
                  File(_wallpaperPath!),
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox(),
                ),
              ),
            ),

          Column(
            children: [
              // Messages List (Huge & Spacious)
              Expanded(
                child: _messages.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.mark_chat_unread_outlined, size: 50, color: AppTheme.primaryLight.withOpacity(0.4)),
                            const SizedBox(height: 10),
                            const Text("أهلاً بكم في عالم أحمد ومروة ❤️", style: TextStyle(fontSize: 15, color: AppTheme.textMuted)),
                            const SizedBox(height: 4),
                            const Text("ابدأوا محادثتكم بأحلى كلام وذكريات...", style: TextStyle(fontSize: 12, color: AppTheme.textHint)),
                          ],
                        ),
                      )
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        itemCount: _messages.length,
                        itemBuilder: (context, index) {
                          final msg = _messages[index];
                          final isMe = msg["sender_phone"] == _myPhone;
                          return _buildMessageBubble(msg, isMe);
                        },
                      ),
              ),

              // Bottom Input Bar
              _buildInputBar(),

              // Comprehensive Emoji Keyboard Tray
              if (_showEmojiPicker) _buildEmojiTray(),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStoryAvatar({
    required String name,
    required String avatar,
    bool isAdd = false,
    bool hasStory = false,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            children: [
              Container(
                padding: const EdgeInsets.all(2.5),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: hasStory
                      ? LinearGradient(colors: [AppTheme.primary, AppTheme.accentPink])
                      : null,
                  border: isAdd ? Border.all(color: Colors.white24, width: 1.5) : null,
                ),
                child: CircleAvatar(
                  radius: 20,
                  backgroundColor: AppTheme.surfaceElevated,
                  child: Text(avatar, style: const TextStyle(fontSize: 18)),
                ),
              ),
              if (isAdd)
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(color: AppTheme.primary, shape: BoxShape.circle),
                    child: const Icon(Icons.add, size: 12, color: Colors.white),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 2),
          Text(name, style: const TextStyle(fontSize: 10, color: Colors.white70)),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> msg, bool isMe) {
    final timestamp = msg["timestamp"] != null
        ? DateTime.fromMillisecondsSinceEpoch((msg["timestamp"] * 1000).toInt())
        : DateTime.now();
    final timeStr = intl.DateFormat('h:mm a').format(timestamp);
    final isLiked = msg["is_liked"] == 1;
    final status = msg["status"] ?? "sent";
    final msgType = msg["msg_type"] ?? "text";
    final mediaUrl = msg["media_url"] ?? "";

    return GestureDetector(
      onDoubleTap: () => _toggleLike(msg),
      onLongPress: () => _showMessageReactionPicker(msg),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            ConstrainedBox(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.78,
              ),
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(10, 8, 10, 6),
                    decoration: BoxDecoration(
                      gradient: isMe
                          ? LinearGradient(
                              colors: [AppTheme.myBubbleStart, AppTheme.myBubbleEnd],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            )
                          : null,
                      color: isMe ? null : AppTheme.partnerBubble.withOpacity(0.95),
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(18),
                        topRight: const Radius.circular(18),
                        bottomLeft: isMe ? const Radius.circular(18) : const Radius.circular(4),
                        bottomRight: isMe ? const Radius.circular(4) : const Radius.circular(18),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Photo Message with Full Aspect Ratio & Zoom Tap
                        if (msgType == "image" && mediaUrl.isNotEmpty) ...[
                          GestureDetector(
                            onTap: () => _openFullScreenImage("${AuthService().serverUrl}$mediaUrl"),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.network(
                                "${AuthService().serverUrl}$mediaUrl",
                                fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) => Container(
                                  height: 120,
                                  color: Colors.black26,
                                  child: const Center(child: Icon(Icons.broken_image, color: Colors.white54)),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                        ],

                        // Video Message
                        if (msgType == "video" && mediaUrl.isNotEmpty) ...[
                          Container(
                            height: 150,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: Colors.black45,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Center(
                              child: CircleAvatar(
                                radius: 24,
                                backgroundColor: Colors.white24,
                                child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 30),
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                        ],

                        // Voice Message
                        if (msgType == "voice") ...[
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const CircleAvatar(
                                radius: 16,
                                backgroundColor: Colors.white24,
                                child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 20),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Container(
                                  height: 4,
                                  decoration: BoxDecoration(
                                    color: Colors.white54,
                                    borderRadius: BorderRadius.circular(2),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              const Text("0:24", style: TextStyle(fontSize: 11, color: Colors.white70)),
                            ],
                          ),
                          const SizedBox(height: 4),
                        ],

                        // Text Content
                        if ((msg["content"] ?? "").isNotEmpty && msgType != "voice")
                          Text(
                            msg["content"],
                            style: const TextStyle(fontSize: 15, color: Colors.white, height: 1.35),
                          ),

                        const SizedBox(height: 4),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(timeStr, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.65))),
                            if (isMe) ...[
                              const SizedBox(width: 4),
                              Icon(
                                status == "read"
                                    ? Icons.done_all_rounded
                                    : (status == "delivered" ? Icons.done_all_rounded : Icons.done_rounded),
                                size: 14,
                                color: status == "read" ? AppTheme.primaryLight : Colors.white.withOpacity(0.65),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Romantic Heart & Emojis Reaction
                  if (isLiked)
                    Positioned(
                      bottom: -8,
                      right: isMe ? null : -6,
                      left: isMe ? -6 : null,
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          color: AppTheme.surfaceElevated,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(color: AppTheme.accentPink.withOpacity(0.4), blurRadius: 8),
                          ],
                        ),
                        child: Text(
                          msg["reaction_emoji"] ?? "❤️",
                          style: const TextStyle(fontSize: 13),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar() {
    final quickRomanticEmojis = ['❤️', '💍', '🥰', '🥺', '🌸', '👰🏻‍♀️', '🤵🏻‍♂️', '✨', '💋', '🔥'];
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surface,
        border: const Border(top: BorderSide(color: Color(0xFF1E1730), width: 1)),
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Quick romantic emoji shortcuts strip
            Container(
              height: 34,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: quickRomanticEmojis.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (ctx, i) {
                  final em = quickRomanticEmojis[i];
                  return InkWell(
                    onTap: () {
                      _recordRecentEmoji(em);
                      final curr = _textController.text;
                      _textController.text = curr + em;
                      _textController.selection = TextSelection.fromPosition(
                        TextPosition(offset: _textController.text.length),
                      );
                      _onTextChanged(_textController.text);
                    },
                    borderRadius: BorderRadius.circular(16),
                    child: Center(
                      child: Text(em, style: const TextStyle(fontSize: 19)),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 2, 10, 8),
              child: Row(
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  color: AppTheme.surfaceElevated,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Row(
                  children: [
                    // Emoji Picker Toggle
                    IconButton(
                      icon: Icon(
                        _showEmojiPicker ? Icons.keyboard_rounded : Icons.sentiment_satisfied_alt_rounded,
                        color: AppTheme.primaryLight,
                        size: 22,
                      ),
                      onPressed: () {
                        setState(() => _showEmojiPicker = !_showEmojiPicker);
                        if (_showEmojiPicker) FocusScope.of(context).unfocus();
                      },
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: _textController,
                        onChanged: _onTextChanged,
                        onTap: () {
                          if (_showEmojiPicker) setState(() => _showEmojiPicker = false);
                        },
                        style: const TextStyle(color: AppTheme.textMain, fontSize: 14.5),
                        decoration: InputDecoration(
                          hintText: "رسالة إلى $_partnerName...",
                          hintStyle: const TextStyle(color: AppTheme.textHint, fontSize: 13.5),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                    // Multi-Image & Video Attachment Button
                    IconButton(
                      icon: Icon(Icons.attach_file_rounded, color: AppTheme.primaryLight, size: 22),
                      onPressed: _showAttachmentSheet,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                    const SizedBox(width: 4),
                    IconButton(
                      icon: Icon(Icons.alarm_rounded, color: AppTheme.primaryLight, size: 21),
                      tooltip: "الرسائل المجدولة والتلقائية ⏰",
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ScheduledMessagesScreen(
                              initialText: _textController.text.trim().isNotEmpty ? _textController.text.trim() : null,
                            ),
                          ),
                        );
                      },
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Voice Note or Send Button
            !_hasText
                ? InkWell(
                    onTap: _sendVoiceNote,
                    borderRadius: BorderRadius.circular(26),
                    child: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFF2A1647), Color(0xFF190C2E)],
                        ),
                        border: Border.all(
                          color: AppTheme.accentPink.withOpacity(0.55),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.accentPink.withOpacity(0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 2),
                          ),
                          BoxShadow(
                            color: AppTheme.primary.withOpacity(0.2),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppTheme.accentPink.withOpacity(0.12),
                            ),
                          ),
                          const Icon(Icons.mic_rounded, color: Colors.white, size: 22),
                          Positioned(
                            top: 8,
                            right: 9,
                            child: Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                color: Color(0xFF10B981),
                                shape: BoxShape.circle,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                : InkWell(
                    onTap: () => _sendMessage(),
                    onLongPress: () {
                      final currentTxt = _textController.text.trim();
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ScheduledMessagesScreen(
                            initialText: currentTxt.isNotEmpty ? currentTxt : null,
                          ),
                        ),
                      );
                    },
                    borderRadius: BorderRadius.circular(24),
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [AppTheme.primary, AppTheme.accentPink],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.primary.withOpacity(0.4),
                            blurRadius: 10,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Icon(Icons.send_rounded, color: Colors.white, size: 19),
                      ),
                    ),
                  ),
          ],
        ),
      ),
    ],
  ),
),
);
  }

  void _showAttachmentSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surfaceElevated,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildAttachmentOption(
                icon: Icons.photo_library_rounded,
                label: "إرسال صور (متعددة) 📷",
                color: AppTheme.primaryLight,
                onTap: () {
                  Navigator.pop(ctx);
                  _pickAndSendMultipleImages();
                },
              ),
              _buildAttachmentOption(
                icon: Icons.videocam_rounded,
                label: "إرسال فيديو 🎥",
                color: AppTheme.accentPink,
                onTap: () {
                  Navigator.pop(ctx);
                  _pickAndSendVideo();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAttachmentOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 32, color: color),
            const SizedBox(height: 8),
            Text(label, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  Widget _buildEmojiTray() {
    List<String> activeList = _recentEmojis;
    if (_selectedEmojiCategory == 1) activeList = _loveEmojis;
    if (_selectedEmojiCategory == 2) activeList = _smileysEmojis;
    if (_selectedEmojiCategory == 3) activeList = _gesturesEmojis;
    if (_selectedEmojiCategory == 4) activeList = _natureEmojis;
    if (_selectedEmojiCategory == 5) activeList = _foodEmojis;
    if (_selectedEmojiCategory == 6) activeList = _activitiesEmojis;
    if (_selectedEmojiCategory == 7) activeList = _travelEmojis;
    if (_selectedEmojiCategory == 8) activeList = _symbolsEmojis;

    return Container(
      height: 270,
      color: AppTheme.surface,
      child: Column(
        children: [
          // Emoji Category Switcher Tabs + Backspace Button
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            color: AppTheme.surfaceElevated,
            child: Row(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _buildEmojiCategoryTab(0, "الأخيرة 🕒"),
                        const SizedBox(width: 5),
                        _buildEmojiCategoryTab(1, "حب ورومانسية ❤️💍"),
                        const SizedBox(width: 5),
                        _buildEmojiCategoryTab(2, "ابتسامات 😊"),
                        const SizedBox(width: 5),
                        _buildEmojiCategoryTab(3, "حركات وأيدي 👍"),
                        const SizedBox(width: 5),
                        _buildEmojiCategoryTab(4, "طبيعة وورود 🌹"),
                        const SizedBox(width: 5),
                        _buildEmojiCategoryTab(5, "أكل ومشروبات ☕"),
                        const SizedBox(width: 5),
                        _buildEmojiCategoryTab(6, "احتفال وألعاب 🎉"),
                        const SizedBox(width: 5),
                        _buildEmojiCategoryTab(7, "سفر وأماكن ✈️"),
                        const SizedBox(width: 5),
                        _buildEmojiCategoryTab(8, "رموز وأشياء 💡"),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                // WhatsApp-style Backspace Button
                InkWell(
                  onTap: () {
                    final text = _textController.text;
                    if (text.isNotEmpty) {
                      final chars = text.characters;
                      if (chars.isNotEmpty) {
                        _textController.text = chars.skipLast(1).toString();
                        _textController.selection = TextSelection.fromPosition(
                          TextPosition(offset: _textController.text.length),
                        );
                        _onTextChanged(_textController.text);
                      }
                    }
                  },
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppTheme.primaryLight.withOpacity(0.2)),
                    ),
                    child: Icon(Icons.backspace_outlined, size: 18, color: AppTheme.primaryLight),
                  ),
                ),
              ],
            ),
          ),
          // Emoji Grid
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(8),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 7,
                crossAxisSpacing: 6,
                mainAxisSpacing: 6,
              ),
              itemCount: activeList.length,
              itemBuilder: (context, idx) {
                final em = activeList[idx];
                return InkWell(
                  onTap: () {
                    _recordRecentEmoji(em);
                    final curr = _textController.text;
                    _textController.text = curr + em;
                    _textController.selection = TextSelection.fromPosition(
                      TextPosition(offset: _textController.text.length),
                    );
                    _onTextChanged(_textController.text);
                  },
                  borderRadius: BorderRadius.circular(8),
                  child: Center(
                    child: Text(em, style: const TextStyle(fontSize: 24)),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
  Widget _buildEmojiCategoryTab(int index, String title) {
    final isSelected = _selectedEmojiCategory == index;
    return GestureDetector(
      onTap: () => setState(() => _selectedEmojiCategory = index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          title,
          style: TextStyle(
            fontSize: 11.5,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected ? Colors.white : AppTheme.textMuted,
          ),
        ),
      ),
    );
  }
}
