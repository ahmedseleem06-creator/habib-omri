import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'chat_screen.dart';
import 'memories_screen.dart';
import 'love_hub_screen.dart';
import 'settings_screen.dart';

class MainNavigationScreen extends StatefulWidget {
  final int initialIndex;
  const MainNavigationScreen({super.key, this.initialIndex = 0});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
  }

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      const ChatScreen(),
      const MemoriesScreen(),
      const LoveHubScreen(),
      SettingsScreen(onWallpaperChanged: () => setState(() {})),
    ];

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: IndexedStack(
        index: _currentIndex,
        children: screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppTheme.surface,
          border: Border(
            top: BorderSide(color: Colors.white.withOpacity(0.06), width: 1),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: 12,
              offset: const Offset(0, -3),
            ),
          ],
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildNavItem(
                  index: 0,
                  icon: Icons.chat_bubble_rounded,
                  label: "الشات",
                ),
                _buildNavItem(
                  index: 1,
                  icon: Icons.favorite_rounded,
                  label: "الذكريات",
                  isRomantic: true,
                ),
                _buildNavItem(
                  index: 2,
                  icon: Icons.auto_awesome_rounded,
                  label: "ركن العشاق",
                  isLoveHub: true,
                ),
                _buildNavItem(
                  index: 3,
                  icon: Icons.tune_rounded,
                  label: "الإعدادات",
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required int index,
    required IconData icon,
    required String label,
    bool isRomantic = false,
    bool isLoveHub = false,
  }) {
    final isSelected = _currentIndex == index;
    final activeColor = isRomantic 
        ? AppTheme.accentPink 
        : (isLoveHub ? const Color(0xFFF472B6) : AppTheme.primaryLight);

    return InkWell(
      onTap: () => _onTabTapped(index),
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(
          horizontal: isSelected ? 12 : 8,
          vertical: 6,
        ),
        decoration: BoxDecoration(
          color: isSelected
              ? (isRomantic
                  ? AppTheme.accentPink.withOpacity(0.18)
                  : (isLoveHub 
                      ? const Color(0xFFF472B6).withOpacity(0.18)
                      : AppTheme.primary.withOpacity(0.2)))
              : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
          border: isSelected
              ? Border.all(
                  color: isRomantic
                      ? AppTheme.accentPink.withOpacity(0.4)
                      : (isLoveHub
                          ? const Color(0xFFF472B6).withOpacity(0.4)
                          : AppTheme.primaryLight.withOpacity(0.4)),
                  width: 1,
                )
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: isRomantic || isLoveHub ? 22 : 20,
              color: isSelected ? activeColor : AppTheme.textHint,
            ),
            if (isSelected) ...[
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.bold,
                  color: activeColor,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
