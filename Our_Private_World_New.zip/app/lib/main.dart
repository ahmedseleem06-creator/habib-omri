import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Load saved theme if any
  try {
    final prefs = await SharedPreferences.getInstance();
    final savedTheme = prefs.getString("selected_app_theme") ?? "violet";
    AppTheme.setTheme(savedTheme);
  } catch (_) {}

  // Set transparent status bar and dark navigation bar
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppTheme.background,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  runApp(const HabibOmriApp());
}

class HabibOmriApp extends StatelessWidget {
  const HabibOmriApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemePreset>(
      valueListenable: AppTheme.themeNotifier,
      builder: (context, currentTheme, _) {
        return MaterialApp(
          title: 'عالمنا الخاص',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.darkTheme,
          home: const SplashScreen(),
        );
      },
    );
  }
}
