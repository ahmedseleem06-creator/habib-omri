@echo off
title Habib Omri Server
cls
echo =======================================================
echo          Habib Omri Server - Running
echo =======================================================
echo.
echo Server Address for Phone:
echo    http://192.168.1.4:8000
echo.
echo =======================================================
echo Press Ctrl + C to stop the server.
echo.

if exist "C:\Users\hossam\Desktop\Our_Private_World_New\server\main.py" (
    cd /d "C:\Users\hossam\Desktop\Our_Private_World_New\server"
) else (
    cd /d "C:\Users\hossam\.gemini\antigravity\scratch\habib_omri\server"
)

"C:\Users\hossam\AppData\Local\Programs\Python\Python313\python.exe" -m uvicorn main:app --host 0.0.0.0 --port 8000
pause
